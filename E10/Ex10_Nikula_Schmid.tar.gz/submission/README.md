# Group info

Jonas Nikula:   2581635
Daniel Schmid:  2548968
