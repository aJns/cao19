import matplotlib.pyplot as plt
import numpy as np

def my_func(x,y):
    # Create  the function here
    # and return appropriate objects

    # TODO

    return 

# creating the grid using np.linspace for plotting
# 100 samples are enough 

x = ... # TODO
y = ...  # TODO

# create meshgrid 
X, Y =    ...  # TODO : use the above created x,y to create the meshgrid

# Create Z by using my_func over the grid
Z = ...


# Start create the figure and the axis
fig = plt.figure()
ax = fig.gca(projection='3d')

# Now create surface plot

# Create x,y,z labels

# Create figures in PDF and PNG format.




