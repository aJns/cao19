import numpy as np
import matplotlib.pyplot as plt

# Let $f$ be a continuous piecewise linear function. We represent $f$ by a sequences
# (t_0, ..., t_{n-1}) of breakpoints
# (f_0, ..., f_{n-1}) values of f at the breakpoints
# (s_0, ..., s_{n-1}) slopes of f, s_i is the slope on (t_{i},t_{i+1}) for 0<i<n
#                          and s_{-1} is the slope on (-\infty,t_0),
#                          and s_{n-1} the slope on (t_{n-1},+\infty)
# Note that this information is redundant.
#

n = 5

# breakpoints
t = np.linspace(-5, 5, n)

# function evaluations at breakpoints
f = t ** 2 - 0.5 * t

s_before = -np.inf  # s_before for s_{-1}

# comprises of s[0] till s[n-1] as per the above description
s = np.zeros(n - 1)  # tentative slopes, see TODO below

s_after = np.inf  # s_after for s_{n-1}

# Note that the domain is only from -5 till 5


# The 's' array contains only tentative slopes, 
# you need to calculate the actual slopes below 
# using the function values at breakpoints.
for i in np.arange(n - 1):
    s[i] = (f[i] - f[i-1]) / (t[i] - t[i - 1])


# NOTE: It seems that the slopes are not used in the template to do anything
# We could use them the check that the function is convex, like in 1a
def is_convex(slopes, s_before=None, s_after=None):
    convex = True

    n_slopes = len(slopes)
    for i in np.arange(n_slopes):
        convex = slopes[i - 1] <= slopes[i]
        if not convex:
            break

    if s_before:
        convex = convex and s_before <= slopes[0]

    if s_after:
        convex = convex and slopes[-1] <= s_after

    return convex


def conjugate_function(y, func_vals, breakpoints):
    # y is the point of evaluation
    # func_vals : Function values
    # breakpoints : original breakpoints
    # DONE: Complete the conjugate function using function values and breakpoints

    retval = np.inf

    if (y < s_after) and (y > s_before):
        vals = -func_vals + y * breakpoints
        retval = np.max(vals)

    return retval


n_2 = 50
t_2 = np.linspace(-10, 10, n_2)

f_2 = [conjugate_function(y, f, t) for y in t_2]  # DONE: Evaluate conjugate_function here over t_2

# Starting the plot
# We want to compare original function and conjugate function side by side.
fig = plt.figure()

# You may use x axis limits from -10 till 10.

ax1 = fig.add_subplot(1, 2, 1)
ax1.set_title('Original function')
ax1.plot(t, f)
plt.grid()
# Plot only on the domain of the function.
# You may skip plotting infinities here.
# Also set the grid of both the axes to 'True'. 

ax2 = fig.add_subplot(1, 2, 2)
ax2.set_title('Conjugate function')
ax2.plot(t_2, f_2)
plt.grid()

# Also set the grid of both the axes to 'True'.

plt.savefig("original_and_conjugate_functions.png")
plt.show()

# DONE: Save the figure as 'original_and_conjugate_functions.png'
